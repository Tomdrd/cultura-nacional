import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { supabase } from '../../lib/supabase';
import { Spacing, FontSize, FontWeight, Radius } from '../../constants/layout';

export function LoginScreen({ navigation }: any) {
  const { colors } = useTheme();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [errors, setErrors]     = useState<{ email?: string; password?: string }>({});

  function validate() {
    const e: typeof errors = {};
    if (!email.trim())           e.email    = 'Informe seu e-mail';
    else if (!email.includes('@')) e.email  = 'E-mail inválido';
    if (!password)               e.password = 'Informe sua senha';
    else if (password.length < 6) e.password = 'Mínimo 6 caracteres';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleLogin() {
    if (!validate()) return;
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) Alert.alert('Erro ao entrar', error.message);
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        style={{ flex: 1, backgroundColor: colors.background }}
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
      >
        {/* Logo */}
        <View style={styles.logoWrap}>
          <View style={[styles.logoCircle, { backgroundColor: '#1A1A1A' }]}>
            <Text style={styles.logoText}>CN</Text>
          </View>
          <Text style={[styles.appName, { color: colors.text }]}>Cultura Nacional</Text>
          <Text style={[styles.appSub, { color: colors.textSecondary }]}>Quanto você sabe sobre o Brasil?</Text>
        </View>

        {/* Form */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.title, { color: colors.text }]}>Entrar</Text>

          <Input
            label="E-mail"
            placeholder="seu@email.com"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            error={errors.email}
          />
          <Input
            label="Senha"
            placeholder="••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            error={errors.password}
          />

          <Button label="Entrar" onPress={handleLogin} loading={loading} style={styles.btn} />

          <TouchableOpacity style={styles.forgot}>
            <Text style={[styles.link, { color: colors.primary }]}>Esqueci minha senha</Text>
          </TouchableOpacity>
        </View>

        {/* Divider */}
        <View style={styles.divider}>
          <View style={[styles.line, { backgroundColor: colors.border }]} />
          <Text style={[styles.divText, { color: colors.textMuted }]}>ou</Text>
          <View style={[styles.line, { backgroundColor: colors.border }]} />
        </View>

        {/* Register */}
        <View style={styles.registerRow}>
          <Text style={[styles.registerText, { color: colors.textSecondary }]}>Ainda não tem conta? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={[styles.link, { color: colors.primary }]}>Cadastre-se</Text>
          </TouchableOpacity>
        </View>

        {/* Flags decoration */}
        <Text style={styles.flags}>🇧🇷</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll:       { flexGrow: 1, padding: Spacing.xl, justifyContent: 'center' },
  logoWrap:     { alignItems: 'center', marginBottom: Spacing.xxl },
  logoCircle:   { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md },
  logoText:     { color: '#FFFFFF', fontSize: 26, fontWeight: '700' },
  appName:      { fontSize: FontSize.xl, fontWeight: FontWeight.bold, letterSpacing: -0.5 },
  appSub:       { fontSize: FontSize.sm, marginTop: 4, textAlign: 'center' },
  card:         { borderRadius: Radius.lg, borderWidth: 0.5, padding: Spacing.xl, marginBottom: Spacing.lg },
  title:        { fontSize: FontSize.lg, fontWeight: FontWeight.bold, marginBottom: Spacing.lg },
  btn:          { marginTop: Spacing.sm },
  forgot:       { alignItems: 'center', marginTop: Spacing.md },
  divider:      { flexDirection: 'row', alignItems: 'center', marginVertical: Spacing.lg },
  line:         { flex: 1, height: 0.5 },
  divText:      { marginHorizontal: Spacing.md, fontSize: FontSize.xs },
  registerRow:  { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  registerText: { fontSize: FontSize.sm },
  link:         { fontSize: FontSize.sm, fontWeight: FontWeight.medium },
  flags:        { textAlign: 'center', fontSize: 28, marginTop: Spacing.xxl },
});
