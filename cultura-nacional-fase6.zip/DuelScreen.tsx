import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Share, Animated } from 'react-native';
import { Swords, Clock, CheckCircle, XCircle, Trophy, Copy, Users } from 'lucide-react-native';
import { useTheme } from '../../hooks/useTheme';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import { Spacing, FontSize, FontWeight, Radius } from '../../constants/layout';

type DuelState = 'lobby' | 'waiting' | 'playing' | 'finished';

interface Question {
  id: string;
  text: string;
  options: string[];
  answer_index: number;
  explanation: string | null;
  difficulty: string;
}

interface Opponent {
  id: string;
  username: string;
  xp: number;
  level: number;
}

const TOTAL_QUESTIONS = 5;
const TIME_PER_QUESTION = 15;

export function DuelScreen({ navigation }: any) {
  const { colors } = useTheme();
  const { user } = useAuthStore();

  const [duelState,  setDuelState]  = useState<DuelState>('lobby');
  const [matchId,    setMatchId]    = useState<string | null>(null);
  const [questions,  setQuestions]  = useState<Question[]>([]);
  const [current,    setCurrent]    = useState(0);
  const [selected,   setSelected]   = useState<number | null>(null);
  const [answered,   setAnswered]   = useState(false);
  const [myScore,    setMyScore]    = useState(0);
  const [oppScore,   setOppScore]   = useState(0);
  const [opponent,   setOpponent]   = useState<Opponent | null>(null);
  const [timeLeft,   setTimeLeft]   = useState(TIME_PER_QUESTION);
  const [myAnswers,  setMyAnswers]   = useState<boolean[]>([]);
  const [loading,    setLoading]    = useState(false);

  const timerRef    = useRef<any>(null);
  const channelRef  = useRef<any>(null);
  const progressAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => { return () => cleanup(); }, []);

  function cleanup() {
    clearInterval(timerRef.current);
    if (channelRef.current) supabase.removeChannel(channelRef.current);
  }

  async function createMatch() {
    if (!user) return;
    setLoading(true);
    const { data: questions } = await supabase
      .from('questions').select('*').eq('active', true).limit(TOTAL_QUESTIONS);

    if (!questions || questions.length === 0) return;

    const { data: match } = await supabase.from('matches').insert({
      player1_id: user.id,
      status: 'waiting',
    }).select().single();

    if (match) {
      setMatchId(match.id);
      setQuestions(questions.sort(() => Math.random() - 0.5));
      setDuelState('waiting');
      subscribeToMatch(match.id);
    }
    setLoading(false);
  }

  function subscribeToMatch(id: string) {
    const channel = supabase.channel(`match:${id}`)
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'matches', filter: `id=eq.${id}`
      }, async (payload) => {
        const match = payload.new as any;
        if (match.status === 'active' && match.player2_id) {
          const { data: oppProfile } = await supabase
            .from('profiles').select('id, username, xp, level').eq('id', match.player2_id).single();
          if (oppProfile) setOpponent(oppProfile);
          setDuelState('playing');
          startTimer();
        }
        if (match.status === 'finished') {
          setDuelState('finished');
          cleanup();
        }
      })
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'match_answers', filter: `match_id=eq.${id}`
      }, (payload) => {
        const answer = payload.new as any;
        if (answer.user_id !== user?.id && answer.is_correct) {
          setOppScore(prev => prev + 1);
        }
      })
      .subscribe();
    channelRef.current = channel;
  }

  async function joinMatch(id: string) {
    if (!user) return;
    setLoading(true);
    const { data: match } = await supabase
      .from('matches').select('*, questions:questions(*)').eq('id', id).single();

    if (!match) { setLoading(false); return; }

    await supabase.from('matches').update({ player2_id: user.id, status: 'active' }).eq('id', id);

    const { data: qs } = await supabase.from('questions').select('*').eq('active', true).limit(TOTAL_QUESTIONS);
    if (qs) setQuestions(qs.sort(() => Math.random() - 0.5));

    const { data: p1 } = await supabase.from('profiles').select('id, username, xp, level').eq('id', match.player1_id).single();
    if (p1) setOpponent(p1);

    setMatchId(id);
    setDuelState('playing');
    subscribeToMatch(id);
    startTimer();
    setLoading(false);
  }

  function startTimer() {
    clearInterval(timerRef.current);
    setTimeLeft(TIME_PER_QUESTION);
    Animated.timing(progressAnim, { toValue: 1, duration: 0, useNativeDriver: false }).start();
    Animated.timing(progressAnim, { toValue: 0, duration: TIME_PER_QUESTION * 1000, useNativeDriver: false }).start();
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) { clearInterval(timerRef.current); if (!answered) handleAnswer(-1); return 0; }
        return prev - 1;
      });
    }, 1000);
  }

  async function handleAnswer(index: number) {
    if (answered || !matchId || !user) return;
    clearInterval(timerRef.current);
    setSelected(index);
    setAnswered(true);

    const q = questions[current];
    const correct = index === q.answer_index;
    if (correct) setMyScore(prev => prev + 1);
    setMyAnswers(prev => [...prev, correct]);

    await supabase.from('match_answers').insert({
      match_id: matchId, user_id: user.id, question_id: q.id,
      answer_index: index, is_correct: correct, time_ms: (TIME_PER_QUESTION - timeLeft) * 1000,
    });

    setTimeout(() => nextQuestion(), 1800);
  }

  async function nextQuestion() {
    if (current + 1 >= questions.length) {
      await supabase.from('matches').update({ status: 'finished', finished_at: new Date().toISOString() }).eq('id', matchId);
      setDuelState('finished');
      cleanup();
    } else {
      setCurrent(prev => prev + 1);
      setSelected(null);
      setAnswered(false);
      startTimer();
    }
  }

  async function shareInvite() {
    await Share.share({ message: `Me desafie no Cultura Nacional! Código do duelo: ${matchId}` });
  }

  const timerColor = timeLeft <= 5 ? colors.danger : timeLeft <= 10 ? '#BA7517' : colors.primary;

  // LOBBY
  if (duelState === 'lobby') {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={[styles.backText, { color: colors.primary }]}>← Voltar</Text>
        </TouchableOpacity>
        <View style={styles.center}>
          <View style={[styles.iconWrap, { backgroundColor: colors.primary + '20' }]}>
            <Swords size={48} color={colors.primary} />
          </View>
          <Text style={[styles.lobbyTitle, { color: colors.text }]}>Duelo 1v1</Text>
          <Text style={[styles.lobbySub, { color: colors.textSecondary }]}>
            Desafie um amigo ou entre em um duelo existente
          </Text>
          <View style={styles.lobbyActions}>
            <TouchableOpacity
              onPress={createMatch}
              style={[styles.lobbyBtn, { backgroundColor: colors.primary }]}
            >
              {loading ? <ActivityIndicator color="#FFF" /> : (
                <>
                  <Swords size={20} color="#FFF" />
                  <Text style={styles.lobbyBtnText}>Criar duelo</Text>
                </>
              )}
            </TouchableOpacity>
            <View style={[styles.divider, { backgroundColor: colors.border }]}>
              <Text style={[styles.dividerText, { color: colors.textMuted, backgroundColor: colors.background }]}>ou</Text>
            </View>
            <View style={[styles.joinCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Users size={18} color={colors.textSecondary} />
              <Text style={[styles.joinText, { color: colors.textSecondary }]}>
                Em breve: entrar com código de duelo
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  }

  // WAITING
  if (duelState === 'waiting') {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={[styles.waitTitle, { color: colors.text }]}>Aguardando oponente...</Text>
          <Text style={[styles.waitSub, { color: colors.textSecondary }]}>Compartilhe o código para desafiar um amigo</Text>
          <View style={[styles.codeCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.codeLabel, { color: colors.textMuted }]}>Código do duelo</Text>
            <Text style={[styles.codeValue, { color: colors.text }]}>{matchId?.slice(0, 8).toUpperCase()}</Text>
          </View>
          <TouchableOpacity
            onPress={shareInvite}
            style={[styles.shareBtn, { backgroundColor: colors.primary + '20', borderColor: colors.primary + '40' }]}
          >
            <Copy size={16} color={colors.primary} />
            <Text style={[styles.shareBtnText, { color: colors.primary }]}>Compartilhar convite</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { cleanup(); setDuelState('lobby'); setMatchId(null); }} style={styles.cancelBtn}>
            <Text style={[styles.cancelText, { color: colors.textMuted }]}>Cancelar</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // PLAYING
  if (duelState === 'playing' && questions.length > 0) {
    const q = questions[current];
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        {/* Score bar */}
        <View style={[styles.scoreBar, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
          <View style={styles.scoreItem}>
            <Text style={[styles.scoreName, { color: colors.primary }]}>Você</Text>
            <Text style={[styles.scoreVal, { color: colors.text }]}>{myScore}</Text>
          </View>
          <View style={[styles.timerBadge, { backgroundColor: timerColor + '20' }]}>
            <Clock size={13} color={timerColor} />
            <Text style={[styles.timerText, { color: timerColor }]}>{timeLeft}s</Text>
          </View>
          <View style={styles.scoreItem}>
            <Text style={[styles.scoreName, { color: colors.textSecondary }]}>{opponent?.username ?? 'Oponente'}</Text>
            <Text style={[styles.scoreVal, { color: colors.text }]}>{oppScore}</Text>
          </View>
        </View>

        {/* Progress */}
        <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
          <Animated.View style={[styles.progressFill, {
            backgroundColor: timerColor,
            width: progressAnim.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
          }]} />
        </View>

        {/* Counter dots */}
        <View style={styles.counterRow}>
          {questions.map((_, i) => (
            <View key={i} style={[styles.counterDot, {
              backgroundColor: i < current ? colors.primary : i === current ? colors.primary + '60' : colors.border
            }]} />
          ))}
        </View>

        <View style={styles.questionWrap}>
          <Text style={[styles.questionText, { color: colors.text }]}>{q.text}</Text>
          <View style={styles.options}>
            {q.options.map((opt, i) => {
              const isCorrect  = i === q.answer_index;
              const isSelected = i === selected;
              let bg = colors.card, border = colors.border, textColor = colors.text;
              if (answered) {
                if (isCorrect)        { bg = '#009C3B20'; border = '#009C3B'; textColor = '#009C3B'; }
                else if (isSelected)  { bg = colors.danger + '20'; border = colors.danger; textColor = colors.danger; }
              } else if (isSelected)  { bg = colors.primary + '15'; border = colors.primary; textColor = colors.primary; }

              return (
                <TouchableOpacity key={i} onPress={() => handleAnswer(i)} disabled={answered}
                  style={[styles.option, { backgroundColor: bg, borderColor: border }]}
                >
                  <View style={[styles.optLetter, { backgroundColor: border + '30' }]}>
                    <Text style={[styles.optLetterText, { color: textColor }]}>{['A','B','C','D'][i]}</Text>
                  </View>
                  <Text style={[styles.optText, { color: textColor }]}>{opt}</Text>
                  {answered && isCorrect  && <CheckCircle size={18} color="#009C3B" />}
                  {answered && isSelected && !isCorrect && <XCircle size={18} color={colors.danger} />}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </View>
    );
  }

  // FINISHED
  if (duelState === 'finished') {
    const iWon = myScore > oppScore;
    const isDraw = myScore === oppScore;
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.center}>
          <View style={[styles.resultIcon, {
            backgroundColor: iWon ? '#FFDF0020' : isDraw ? colors.primary + '20' : colors.danger + '20'
          }]}>
            <Trophy size={48} color={iWon ? '#FFDF00' : isDraw ? colors.primary : colors.danger} />
          </View>
          <Text style={[styles.resultTitle, { color: colors.text }]}>
            {iWon ? 'Você venceu!' : isDraw ? 'Empate!' : 'Você perdeu!'}
          </Text>
          <View style={[styles.finalScore, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.finalItem}>
              <Text style={[styles.finalName, { color: colors.primary }]}>Você</Text>
              <Text style={[styles.finalVal, { color: colors.text }]}>{myScore}</Text>
            </View>
            <Text style={[styles.finalX, { color: colors.textMuted }]}>×</Text>
            <View style={styles.finalItem}>
              <Text style={[styles.finalName, { color: colors.textSecondary }]}>{opponent?.username}</Text>
              <Text style={[styles.finalVal, { color: colors.text }]}>{oppScore}</Text>
            </View>
          </View>
          <View style={styles.resultDots}>
            {myAnswers.map((r, i) => (
              <View key={i} style={[styles.dot, { backgroundColor: r ? colors.primary : colors.danger }]} />
            ))}
          </View>
          <TouchableOpacity
            onPress={() => { setDuelState('lobby'); setCurrent(0); setMyScore(0); setOppScore(0); setMyAnswers([]); setOpponent(null); setMatchId(null); }}
            style={[styles.replayBtn, { backgroundColor: colors.primary }]}
          >
            <Text style={styles.replayBtnText}>Jogar novamente</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.homeBtn}>
            <Text style={[styles.homeBtnText, { color: colors.textSecondary }]}>Voltar ao início</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, styles.center, { backgroundColor: colors.background }]}>
      <ActivityIndicator color={colors.primary} size="large" />
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  backBtn:      { padding: Spacing.xl, paddingTop: 60 },
  backText:     { fontSize: FontSize.sm, fontWeight: FontWeight.medium },
  iconWrap:     { width: 100, height: 100, borderRadius: 50, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.lg },
  lobbyTitle:   { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, marginBottom: 8 },
  lobbySub:     { fontSize: FontSize.sm, textAlign: 'center', lineHeight: 22, marginBottom: Spacing.xxl },
  lobbyActions: { width: '100%', gap: 16 },
  lobbyBtn:     { height: 52, borderRadius: Radius.md, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  lobbyBtnText: { color: '#FFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
  divider:      { height: 0.5, position: 'relative', alignItems: 'center' },
  dividerText:  { position: 'absolute', paddingHorizontal: 12, fontSize: FontSize.xs, top: -8 },
  joinCard:     { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: Radius.md, borderWidth: 0.5, padding: Spacing.md },
  joinText:     { fontSize: FontSize.sm, flex: 1 },
  waitTitle:    { fontSize: FontSize.xl, fontWeight: FontWeight.bold, marginTop: Spacing.xl, marginBottom: 8 },
  waitSub:      { fontSize: FontSize.sm, textAlign: 'center', marginBottom: Spacing.xl },
  codeCard:     { borderRadius: Radius.lg, borderWidth: 0.5, padding: Spacing.xl, alignItems: 'center', width: '100%', marginBottom: Spacing.md },
  codeLabel:    { fontSize: FontSize.xs, marginBottom: 6 },
  codeValue:    { fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 4 },
  shareBtn:     { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 20, paddingVertical: 12, borderRadius: Radius.md, borderWidth: 0.5, marginBottom: Spacing.md },
  shareBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.medium },
  cancelBtn:    { padding: Spacing.md },
  cancelText:   { fontSize: FontSize.sm },
  scoreBar:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.xl, paddingTop: 56, borderBottomWidth: 0.5 },
  scoreItem:    { alignItems: 'center', gap: 2 },
  scoreName:    { fontSize: FontSize.xs, fontWeight: FontWeight.medium },
  scoreVal:     { fontSize: FontSize.xxl, fontWeight: FontWeight.bold },
  timerBadge:   { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full },
  timerText:    { fontSize: FontSize.sm, fontWeight: FontWeight.bold },
  progressBg:   { height: 3 },
  progressFill: { height: 3 },
  counterRow:   { flexDirection: 'row', gap: 6, padding: Spacing.xl, paddingBottom: 0 },
  counterDot:   { flex: 1, height: 4, borderRadius: 2 },
  questionWrap: { flex: 1, padding: Spacing.xl },
  questionText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, lineHeight: 28, marginBottom: Spacing.xl },
  options:      { gap: 10 },
  option:       { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, borderWidth: 0.5, padding: Spacing.md, gap: 12 },
  optLetter:    { width: 30, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  optLetterText:{ fontSize: FontSize.sm, fontWeight: FontWeight.bold },
  optText:      { flex: 1, fontSize: FontSize.sm, lineHeight: 20 },
  resultIcon:   { width: 100, height: 100, borderRadius: 50, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.lg },
  resultTitle:  { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, marginBottom: Spacing.xl },
  finalScore:   { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.lg, borderWidth: 0.5, padding: Spacing.xl, gap: Spacing.xl, marginBottom: Spacing.xl },
  finalItem:    { alignItems: 'center', gap: 4 },
  finalName:    { fontSize: FontSize.sm, fontWeight: FontWeight.medium },
  finalVal:     { fontSize: 40, fontWeight: FontWeight.bold },
  finalX:       { fontSize: FontSize.xl },
  resultDots:   { flexDirection: 'row', gap: 8, marginBottom: Spacing.xl },
  dot:          { width: 10, height: 10, borderRadius: 5 },
  replayBtn:    { width: '100%', height: 50, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  replayBtnText:{ color: '#FFF', fontSize: FontSize.md, fontWeight: FontWeight.medium },
  homeBtn:      { padding: Spacing.md },
  homeBtnText:  { fontSize: FontSize.sm },
});
